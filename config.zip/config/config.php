<?php
$Host	= 'localhost';
$User	= 'root';
$Pass	= '';
$db		= 'setapdf_db';
$setapdf = mysqli_connect($Host,$User,$Pass);

if(!$setapdf){echo 'Server Not Connect!';exit;}

$db_setapdf = mysqli_select_db($setapdf,$db);
if(!$db_setapdf){echo 'Database Not Connect!';exit;}
?>