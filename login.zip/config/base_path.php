<?php 
define('base_url', 'http://localhost/seta_pdf_form/');
?>