<div class="col-md-12">
	<div class="row">
        <div class="form-group col-lg-8">
            <label>Mailing Address:</label>
            <input type="text" class="form-control" name="mail_address" placeholder="Mailing Address">
        </div>
        <div class="form-group col-lg-4">
            <label>Apt.#/Unit:</label>
            <input type="text" class="form-control" name="mail_unit" placeholder="Unit">
        </div>
    </div>
    <div class="row">
        <div class="form-group col-lg-3">
            <label>City:</label>
            <input type="text" class="form-control" name="mail_city" placeholder="City">
        </div>
        <div class="form-group col-lg-3">
            <label>Province:</label>
            <input type="text" class="form-control" name="mail_province" placeholder="Province">
        </div>
        <div class="form-group col-lg-3">
            <label>Postal Code:</label>
            <input type="text" class="form-control" name="mail_postal" placeholder="Postal Code">
        </div>
        <div class="form-group col-lg-3">
            <label>Country:</label>
            <input type="text" class="form-control" name="mail_country" placeholder="Country">
        </div>
    </div>
</div>