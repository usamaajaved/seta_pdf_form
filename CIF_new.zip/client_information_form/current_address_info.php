<div class="col-md-12">
	<div class="row">
        <div class="form-group col-lg-8">
            <label>Current Home Address:</label>
            <input type="text" class="form-control" name="current_address" placeholder="Current Address">
        </div>
        <div class="form-group col-lg-4">
            <label>Apt.#/Unit:</label>
            <input type="text" class="form-control" name="current_unit" placeholder="Unit">
        </div>
    </div>
    <div class="row">
        <div class="form-group col-lg-3">
            <label>City:</label>
            <input type="text" class="form-control" name="current_city" placeholder="City">
        </div>
        <div class="form-group col-lg-3">
            <label>Province:</label>
            <input type="text" class="form-control" name="current_province" placeholder="Province">
        </div>
        <div class="form-group col-lg-3">
            <label>Postal Code:</label>
            <input type="text" class="form-control" name="current_postal" placeholder="Postal Code">
        </div>
        <div class="form-group col-lg-3">
            <label>Country:</label>
            <input type="text" class="form-control" name="current_country" placeholder="Country">
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <label>When did you move to this address?</label>
        </div>
    </div>
    <div class="row">
        <div class="form-group col-lg-6">
            <label>From (MM/DD/YYYY):</label>
            <div class="input-group">
                <span class="input-group-prepend">
                    <span class="input-group-text"><i class="icon-calendar22"></i></span>
                </span>
                <input type="text" class="form-control daterange-single" name="current_date_from" value="03/18/2013">
            </div>
            <!-- <input type="text" class="form-control" name="current_date_from" placeholder="From"> -->
        </div>
        <div class="form-group col-lg-6">
            <label>To:</label>
            <input type="text" class="form-control" name="current_date_present" placeholder="Present" readonly="">
        </div>
    </div>
</div>