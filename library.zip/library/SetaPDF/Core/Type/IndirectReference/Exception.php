<?php
/**
 * This file is part of the SetaPDF-Core Component
 * 
 * @copyright  Copyright (c) 2015 Setasign - Jan Slabon (http://www.setasign.com)
 * @category   SetaPDF
 * @package    SetaPDF_Core
 * @subpackage Type
 * @license    http://www.setasign.com/ Commercial
 * @version    $Id: Exception.php 698 2015-02-04 15:48:35Z maximilian.kresse $
 */

/**
 * Indirect reference exception
 * 
 * @copyright  Copyright (c) 2015 Setasign - Jan Slabon (http://www.setasign.com)
 * @category   SetaPDF
 * @package    SetaPDF_Core
 * @subpackage Type
 * @license    http://www.setasign.com/ Commercial
 */
class SetaPDF_Core_Type_IndirectReference_Exception extends SetaPDF_Core_Type_Exception
{
    /** Constants prefix: 0x08 **/
}