<?php
/**
 * This file is part of the SetaPDF-Core Component
 *
 * @copyright  Copyright (c) 2015 Setasign - Jan Slabon (http://www.setasign.com)
 * @category   SetaPDF
 * @package    SetaPDF_Core
 * @subpackage Font
 * @license    http://www.setasign.com/ Commercial
 * @version    $Id: Simple.php 720 2015-05-13 09:43:37Z jan.slabon $
 */

/**
 * Abstract class for simple fonts.
 *
 * 9.5 Introduction to Font Data Structures:
 * "[...]Type 0 fonts are called composite fonts; other types of fonts are called simple fonts.[...]"
 *
 * @copyright  Copyright (c) 2015 Setasign - Jan Slabon (http://www.setasign.com)
 * @category   SetaPDF
 * @package    SetaPDF_Core
 * @subpackage Font
 * @license    http://www.setasign.com/ Commercial
 */
abstract class SetaPDF_Core_Font_Simple extends SetaPDF_Core_Font
{
    /**
     * The encoding table
     *
     * @var array
     */
    protected $_encodingTable = null;

    /**
     * The map that maps character codes to uncidoe values
     *
     * @var array
     */
    protected $_toUnicodeTable = null;

    /**
     * Get the encoding table based on the Encoding dictionary and it's Differences entry (if available).
     *
     * @return array
     */
    protected function _getEncodingTable()
    {
        if (null === $this->_encodingTable) {
            /* 1. Check for an existing encoding which
             *    overwrites the fonts build in encoding
             */
            $baseEncoding = false;
            $diff = array();

            if ($this->_dictionary->offsetExists('Encoding')) {
                $encoding = $this->_dictionary->offsetGet('Encoding')->ensure();
                if ($encoding instanceof SetaPDF_Core_Type_Name) {
                    $baseEncoding = $encoding->getValue();
                    $diff = array();
                } else {
                    $baseEncoding = $encoding->offsetExists('BaseEncoding')
                        ? $encoding->offsetGet('BaseEncoding')->getValue()->toPhp()
                        : false;

                    $diff = $encoding->offsetExists('Differences')
                        ? $encoding->offsetGet('Differences')->getValue()->toPhp()
                        : array();
                }
            }

            if ($baseEncoding) {
                $baseEncoding = substr($baseEncoding, 0, strpos($baseEncoding, 'Encoding'));
                $className = 'SetaPDF_Core_Encoding_' . $baseEncoding;
                $baseEncodingTable = call_user_func(array($className, 'getTable'));
            } else {
                $baseEncodingTable = $this->getBaseEncodingTable();
            }

            $newBaseEncodingTable = array();

            $currentCharCode = null;
            foreach ($diff AS $value) {
                if (is_double($value)) {
                    $currentCharCode = $value;
                    continue;
                }

                $utf16BeCodePoint = SetaPDF_Core_Font_Glyph_List::byName($value);

                if ($utf16BeCodePoint !== '') {
                    if (isset($newBaseEncodingTable[$utf16BeCodePoint])) {
                        if (!is_array($newBaseEncodingTable[$utf16BeCodePoint])) {
                            $newBaseEncodingTable[$utf16BeCodePoint] = array($newBaseEncodingTable[$utf16BeCodePoint]);
                        }
                        $newBaseEncodingTable[$utf16BeCodePoint][] = chr($currentCharCode);
                    } else {
                        $newBaseEncodingTable[$utf16BeCodePoint] = chr($currentCharCode);
                    }
                }
                $currentCharCode++;
            }

            foreach ($baseEncodingTable AS $key => $value) {
                if (!isset($newBaseEncodingTable[$key])) {
                    $newBaseEncodingTable[$key] = $value;
                }
            }

            $this->_encodingTable = $this->_sortByArray($newBaseEncodingTable);

            // Try to get the "?" as substitute character
            $this->_substituteCharacter = SetaPDF_Core_Encoding::fromUtf16Be($this->_encodingTable, "\x00\x3F", true);
        }

        return $this->_encodingTable;
    }

    /**
     * Sorts an array by shifting the array values to the top of the resulting array.
     *
     * @param $array
     * @return array
     */
    protected function _sortByArray($array)
    {
        $pre = array();
        $post = array();

        foreach ($array AS $k => $v) {
            if (is_array($v)) {
                $pre[$k] = $v;
            } else {
                $post[$k] = $v;
            }
        }

        return array_merge($pre, $post);
    }

    /**
     * Get the map that maps character codes to unicode values.
     *
     * @return SetaPDF_Core_Font_Cmap|array|false
     */
    protected function _getCharCodesTable()
    {
        if (null === $this->_toUnicodeTable) {
            if ($this->_dictionary->offsetExists('ToUnicode')) {
                $toUnicodeStream = $this->_dictionary->getValue('ToUnicode')->ensure();

                $stream = $toUnicodeStream->getStream();
                $this->_toUnicodeTable = SetaPDF_Core_Font_Cmap::create(new SetaPDF_Core_Reader_String($stream));

                return $this->_toUnicodeTable;
            }
        } else {
            return $this->_toUnicodeTable;
        }

        $encodingTable = $this->_getEncodingTable();
        if ($encodingTable) {
            return $encodingTable;
        }

        $unknownEncoding = array();
        for ($i = 0; $i < 256; $i++) {
            $unknownEncoding[] = chr($i);
        }

        return array(
            "\x00\x3F" => $unknownEncoding
        );
    }
}