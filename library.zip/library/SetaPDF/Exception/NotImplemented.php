<?php
/**
 * This file is part of the SetaPDF library
 * 
 * @copyright  Copyright (c) 2015 Setasign - Jan Slabon (http://www.setasign.com)
 * @category   SetaPDF
 * @package    SetaPDF
 * @license    http://www.setasign.com/ Commercial
 * @version    $Id: NotImplemented.php 698 2015-02-04 15:48:35Z maximilian.kresse $
 */

/**
 * Not implemented exception
 * 
 * @copyright  Copyright (c) 2015 Setasign - Jan Slabon (http://www.setasign.com)
 * @category   SetaPDF
 * @package    SetaPDF
 * @license    http://www.setasign.com/ Commercial
 */
class SetaPDF_Exception_NotImplemented extends SetaPDF_Exception
{}